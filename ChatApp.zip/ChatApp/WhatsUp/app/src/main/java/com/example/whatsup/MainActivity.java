package com.example.whatsup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Toolbar;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    private Toolbar actionbar;
    private View vpMain;
    private TabLayout tabsMain;
    private TabsAdapter tabsAdapter;


    @SuppressLint("ResourceType")
    public void init(){
        actionbar = (Toolbar) findViewById(R.id.actionBar);
        setSupportActionBar(actionbar);
        getSupportActionBar().setTitle(R.id.app_name);

        vpMain =(ViewPager) findViewById(R.id.vpMain);
        tabsAdapter =new TabsAdapter(getSupportFragmentManager());


        tabsMain=(TabLayout) findViewById(R.id.tabsMain);
        tabsMain.setupWithViewPager((ViewPager) vpMain);
    }

    private void setSupportActionBar(Toolbar actionbar) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}